// generated from rosidl_generator_c/resource/idl.h.em
// with input from my_interfaces:msg/HardwareStatus.idl
// generated code does not contain a copyright notice

#ifndef MY_INTERFACES__MSG__HARDWARE_STATUS_H_
#define MY_INTERFACES__MSG__HARDWARE_STATUS_H_

#include "my_interfaces/msg/detail/hardware_status__struct.h"
#include "my_interfaces/msg/detail/hardware_status__functions.h"
#include "my_interfaces/msg/detail/hardware_status__type_support.h"

#endif  // MY_INTERFACES__MSG__HARDWARE_STATUS_H_

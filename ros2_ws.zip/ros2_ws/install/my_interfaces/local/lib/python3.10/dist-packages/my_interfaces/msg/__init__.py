from my_interfaces.msg._hardware_status import HardwareStatus  # noqa: F401

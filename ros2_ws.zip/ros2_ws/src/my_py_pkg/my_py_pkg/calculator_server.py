#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from my_interfaces.srv import Operations


class CalculatorServerNode(Node): 
    def __init__(self):
        super().__init__("calculator_server")
        self._server = self.create_service(
            AddTwoInts, "add_two_ints", self.callback_add_two_ints)
        self.get_logger().info("A calculadora esta on")

    def callback_add_two_ints(self, request, response):

        if request.op == "+":
            response.result = request.a + request.b
            
        elif request.op == "-":
            response.result = request.a - request.b
            
        elif request.op == "*":
            response.result = request.a * request.b
            
        elif request.op == "/":
            response.result = request.a / request.b
        
        else:
            self.get_logger().info("Operador inválido, envie a requisicao novamente.")
            return response
        
        self.get_logger().info(
            "Recebi os números " + str(request.a) + " e " + str(request.b) +
            " e estou retornando " + str(response.result))
        return response


def main(args=None):
    rclpy.init(args=args)
    node = CalculatorServerNode()
    rclpy.spin(node)
    rclpy.shutdown()